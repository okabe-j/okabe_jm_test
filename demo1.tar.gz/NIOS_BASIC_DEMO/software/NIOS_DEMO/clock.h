#ifndef CLOCK_H_
#define CLOCK_H_


bool CLOCK_Test(alt_u32 BaseAddr, alt_u32 TargetCnt, alt_u32 *pclk1, alt_u32 *pclk2);

#endif /*CLOCK_H_*/
