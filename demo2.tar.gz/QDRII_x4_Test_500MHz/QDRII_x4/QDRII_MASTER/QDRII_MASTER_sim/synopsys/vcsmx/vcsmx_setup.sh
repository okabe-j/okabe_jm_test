
# (C) 2001-2013 Altera Corporation. All rights reserved.
# Your use of Altera Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Altera 
# Program License Subscription Agreement, Altera MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Altera and sold by Altera 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ACDS 13.0 156 win32 2013.06.09.15:44:27

# ----------------------------------------
# vcsmx - auto-generated simulation script

# ----------------------------------------
# initialize variables
TOP_LEVEL_NAME="QDRII_MASTER"
QSYS_SIMDIR="./../../"
QUARTUS_INSTALL_DIR="C:/altera/13.0/quartus/"
SKIP_FILE_COPY=0
SKIP_DEV_COM=0
SKIP_COM=0
SKIP_ELAB=0
SKIP_SIM=0
USER_DEFINED_ELAB_OPTIONS=""
USER_DEFINED_SIM_OPTIONS="+vcs+finish+100"

# ----------------------------------------
# overwrite variables - DO NOT MODIFY!
# This block evaluates each command line argument, typically used for 
# overwriting variables. An example usage:
#   sh <simulator>_setup.sh SKIP_ELAB=1 SKIP_SIM=1
for expression in "$@"; do
  eval $expression
  if [ $? -ne 0 ]; then
    echo "Error: This command line argument, \"$expression\", is/has an invalid expression." >&2
    exit $?
  fi
done

# ----------------------------------------
# create compilation libraries
mkdir -p ./libraries/work/
mkdir -p ./libraries/dll0/
mkdir -p ./libraries/oct0/
mkdir -p ./libraries/c0/
mkdir -p ./libraries/s0/
mkdir -p ./libraries/m0/
mkdir -p ./libraries/p0/
mkdir -p ./libraries/pll0/
mkdir -p ./libraries/QDRII_MASTER/
mkdir -p ./libraries/altera_ver/
mkdir -p ./libraries/lpm_ver/
mkdir -p ./libraries/sgate_ver/
mkdir -p ./libraries/altera_mf_ver/
mkdir -p ./libraries/altera_lnsim_ver/
mkdir -p ./libraries/stratixv_ver/
mkdir -p ./libraries/stratixv_hssi_ver/
mkdir -p ./libraries/stratixv_pcie_hip_ver/

# ----------------------------------------
# copy RAM/ROM files to simulation directory
if [ $SKIP_FILE_COPY -eq 0 ]; then
  cp -f $QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_sequencer_mem.hex ./
  cp -f $QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_AC_ROM.hex ./
  cp -f $QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_inst_ROM.hex ./
fi

# ----------------------------------------
# compile device library files
if [ $SKIP_DEV_COM -eq 0 ]; then
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v"                       -work altera_ver           
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v"                                -work lpm_ver              
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v"                                   -work sgate_ver            
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v"                               -work altera_mf_ver        
  vlogan +v2k -sverilog "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv"                           -work altera_lnsim_ver     
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/stratixv_atoms_ncrypt.v"          -work stratixv_ver         
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/stratixv_atoms.v"                          -work stratixv_ver         
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/stratixv_hssi_atoms_ncrypt.v"     -work stratixv_hssi_ver    
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/stratixv_hssi_atoms.v"                     -work stratixv_hssi_ver    
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/stratixv_pcie_hip_atoms_ncrypt.v" -work stratixv_pcie_hip_ver
  vlogan +v2k           "$QUARTUS_INSTALL_DIR/eda/sim_lib/stratixv_pcie_hip_atoms.v"                 -work stratixv_pcie_hip_ver
fi

# ----------------------------------------
# compile design files in correct order
if [ $SKIP_COM -eq 0 ]; then
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_mem_if_dll_stratixv.sv"                                         -work dll0        
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_mem_if_oct_stratixv.sv"                                         -work oct0        
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/alt_qdr_controller_hr_bl4.sv"                                          -work c0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/alt_qdr_controller_top_hr_bl4.sv"                                      -work c0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/alt_qdr_afi_hr_bl4.sv"                                                 -work c0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/alt_qdr_fsm_no_ifdef_params.sv"                                        -work c0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/memctl_parity.sv"                                                      -work c0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/memctl_reset_sync.v"                                                   -work c0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/memctl_burst_latency_shifter_ctl_bl_is_one.sv"                         -work c0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/memctl_data_if_ctl_bl_is_one_qdrii.sv"                                 -work c0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0.v"                                                     -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/altera_avalon_sc_fifo.v"                                               -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/altera_mem_if_sequencer_cpu_no_ifdef_params_sim_cpu_inst.v"            -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/altera_mem_if_sequencer_cpu_no_ifdef_params_sim_cpu_inst_test_bench.v" -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_mem_if_sequencer_mem_no_ifdef_params.sv"                        -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_mem_if_sequencer_rst.sv"                                        -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_merlin_arbitrator.sv"                                           -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_merlin_burst_uncompressor.sv"                                   -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_merlin_master_agent.sv"                                         -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_merlin_master_translator.sv"                                    -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_merlin_slave_agent.sv"                                          -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altera_merlin_slave_translator.sv"                                     -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_addr_router.sv"                                        -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_addr_router_001.sv"                                    -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_cmd_xbar_demux.sv"                                     -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_cmd_xbar_demux_001.sv"                                 -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_cmd_xbar_mux_003.sv"                                   -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_id_router.sv"                                          -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_id_router_003.sv"                                      -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_irq_mapper.sv"                                         -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_rsp_xbar_demux_003.sv"                                 -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_s0_rsp_xbar_mux.sv"                                       -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_ac_ROM_no_ifdef_params.v"                                   -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_ac_ROM_reg.v"                                               -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_bitcheck.v"                                                 -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_core.sv"                                                    -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_datamux.v"                                                  -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_data_broadcast.v"                                           -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_data_decoder.v"                                             -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_di_buffer.v"                                                -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_di_buffer_wrap.v"                                           -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_dm_decoder.v"                                               -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_generic.sv"                                                 -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_inst_ROM_no_ifdef_params.v"                                 -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_inst_ROM_reg.v"                                             -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_jumplogic.v"                                                -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_lfsr12.v"                                                   -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_lfsr36.v"                                                   -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_lfsr72.v"                                                   -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_pattern_fifo.v"                                             -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_qdrii.v"                                                    -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_ram.v"                                                      -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_ram_csr.v"                                                  -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_read_datapath.v"                                            -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/rw_manager_write_decoder.v"                                            -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_data_mgr.sv"                                                 -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_phy_mgr.sv"                                                  -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_reg_file.sv"                                                 -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_acv_phase_decode.v"                                      -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_acv_wrapper.sv"                                          -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_mgr.sv"                                                  -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_reg_file.v"                                              -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_siii_phase_decode.v"                                     -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_siii_wrapper.sv"                                         -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_sv_phase_decode.v"                                       -work s0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/sequencer_scc_sv_wrapper.sv"                                           -work s0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/afi_mux_qdrii.v"                                                       -work m0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_clock_pair_generator.v"                                -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_read_valid_selector.v"                                 -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_addr_cmd_datapath.v"                                   -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_reset.v"                                               -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_acv_ldc.v"                                             -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_memphy.sv"                                             -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_reset_sync.v"                                          -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_new_io_pads.v"                                         -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_flop_mem.v"                                            -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_fr_cycle_shifter.v"                                    -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_read_datapath.sv"                                      -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_write_datapath.v"                                      -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_simple_ddio_out.sv"                                    -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_addr_cmd_ldc_pads.v"                                   -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_addr_cmd_ldc_pad.v"                                    -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_addr_cmd_non_ldc_pad.v"                                -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/read_fifo_hard_abstract_no_ifdef_params.sv"                            -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_read_fifo_hard.v"                                      -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0.sv"                                                    -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_altdqdqs.v"                                            -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altdq_dqs2_stratixv.sv"                                                -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altdq_dqs2_abstract.sv"                                                -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/altdq_dqs2_cal_delays.sv"                                              -work p0          
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_p0_altdqdqs_in.v"                                         -work p0          
  vlogan +v2k -sverilog "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_pll0.sv"                                                  -work pll0        
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER/QDRII_MASTER_0002.v"                                                   -work QDRII_MASTER
  vlogan +v2k           "$QSYS_SIMDIR/QDRII_MASTER.v"                                                                                       
fi

# ----------------------------------------
# elaborate top level design
if [ $SKIP_ELAB -eq 0 ]; then
  vcs -lca -t ps $USER_DEFINED_ELAB_OPTIONS $TOP_LEVEL_NAME
fi

# ----------------------------------------
# simulate
if [ $SKIP_SIM -eq 0 ]; then
  ./simv $USER_DEFINED_SIM_OPTIONS
fi
